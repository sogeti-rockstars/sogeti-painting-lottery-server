package com.sogetirockstars.sogetipaintinglotteryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SogetiPaintingLotteryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SogetiPaintingLotteryServerApplication.class, args);
	}

}
